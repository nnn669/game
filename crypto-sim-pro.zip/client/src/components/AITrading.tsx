import React from 'react';
import { useGame } from '@/contexts/GameContext';

export default function AITrading() {
  const { state, dispatch } = useGame();

  const handleToggleAI = () => {
    dispatch({ type: 'TOGGLE_AI' });
  };

  const handleModeChange = (mode: 'conservative' | 'balanced' | 'aggressive') => {
    dispatch({ type: 'SET_AI_MODE', payload: mode });
  };

  const winRate = state.totalTrades > 0 ? (state.winTrades / state.totalTrades) * 100 : 0;

  return (
    <div className="space-y-6">
      {/* AI 状态卡片 */}
      <div className={`rounded-2xl p-8 text-white shadow-lg ${
        state.aiEnabled
          ? 'bg-gradient-to-br from-blue-500 to-blue-700'
          : 'bg-gradient-to-br from-gray-400 to-gray-600'
      }`}>
        <div className="flex justify-between items-start mb-6">
          <div>
            <h2 className="text-3xl font-bold">🤖 AI 自动交易</h2>
            <p className="text-sm opacity-90 mt-2">智能交易助手，自动执行交易策略</p>
          </div>
          <div className="text-5xl">{state.aiEnabled ? '✅' : '⏸️'}</div>
        </div>

        <button
          onClick={handleToggleAI}
          className={`w-full py-3 px-6 rounded-lg font-bold text-lg transition-all ${
            state.aiEnabled
              ? 'bg-red-500 hover:bg-red-600'
              : 'bg-green-500 hover:bg-green-600'
          }`}
        >
          {state.aiEnabled ? '🛑 关闭 AI 交易' : '▶️ 启动 AI 交易'}
        </button>
      </div>

      {/* 交易模式选择 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h3 className="text-xl font-bold text-gray-900 mb-4">🎯 交易模式</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <ModeCard
            icon="🛡️"
            title="保守模式"
            description="低风险，稳定收益"
            active={state.aiMode === 'conservative'}
            onClick={() => handleModeChange('conservative')}
          />
          <ModeCard
            icon="⚖️"
            title="平衡模式"
            description="中等风险，适度收益"
            active={state.aiMode === 'balanced'}
            onClick={() => handleModeChange('balanced')}
          />
          <ModeCard
            icon="🚀"
            title="激进模式"
            description="高风险，高收益"
            active={state.aiMode === 'aggressive'}
            onClick={() => handleModeChange('aggressive')}
          />
        </div>
      </div>

      {/* 交易统计 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h3 className="text-xl font-bold text-gray-900 mb-4">📈 交易统计</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard
            label="总交易数"
            value={state.totalTrades.toString()}
            color="from-blue-50 to-blue-100"
          />
          <StatCard
            label="盈利笔数"
            value={state.winTrades.toString()}
            color="from-green-50 to-green-100"
          />
          <StatCard
            label="胜率"
            value={`${winRate.toFixed(1)}%`}
            color="from-purple-50 to-purple-100"
          />
          <StatCard
            label="总收益"
            value={`$${(state.totalProfit / 1000).toFixed(1)}K`}
            color="from-yellow-50 to-yellow-100"
          />
        </div>
      </div>

      {/* 最近交易 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h3 className="text-xl font-bold text-gray-900 mb-4">📊 最近交易</h3>
        {state.trades.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-4xl mb-2">📭</div>
            <p className="text-gray-600">还没有交易记录</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {state.trades.slice(-10).reverse().map((trade) => (
              <div
                key={trade.id}
                className="flex justify-between items-center p-4 bg-gradient-to-r from-slate-50 to-slate-100 rounded-lg"
              >
                <div>
                  <div className="font-bold text-gray-900">
                    {trade.type === 'buy' ? '🟢 买入' : '🔴 卖出'} {trade.currencyId}
                  </div>
                  <div className="text-sm text-gray-600">
                    {new Date(trade.timestamp).toLocaleTimeString()}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-gray-900">{trade.qty.toFixed(6)}</div>
                  <div className="text-sm text-gray-600">${trade.price.toFixed(2)}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ModeCard({
  icon,
  title,
  description,
  active,
  onClick,
}: {
  icon: string;
  title: string;
  description: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`p-6 rounded-xl transition-all text-left ${
        active
          ? 'bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-lg'
          : 'bg-gradient-to-br from-slate-50 to-slate-100 text-gray-900 hover:shadow-md'
      }`}
    >
      <div className="text-3xl mb-2">{icon}</div>
      <h4 className="font-bold text-lg">{title}</h4>
      <p className={`text-sm ${active ? 'opacity-90' : 'text-gray-600'}`}>{description}</p>
    </button>
  );
}

function StatCard({
  label,
  value,
  color,
}: {
  label: string;
  value: string;
  color: string;
}) {
  return (
    <div className={`bg-gradient-to-br ${color} rounded-xl p-4`}>
      <div className="text-sm text-gray-600 mb-2">{label}</div>
      <div className="text-2xl font-bold text-gray-900">{value}</div>
    </div>
  );
}
