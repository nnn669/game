import React from 'react';
import { useGame } from '@/contexts/GameContext';

export default function AchievementPanel() {
  const { state } = useGame();

  const unlockedCount = state.achievements.filter(a => a.unlocked).length;

  return (
    <div className="space-y-6">
      {/* 成就概览 */}
      <div className="bg-gradient-to-br from-yellow-400 to-orange-600 rounded-2xl p-8 text-white shadow-lg">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-3xl font-bold">🏆 成就系统</h2>
            <p className="text-sm opacity-90 mt-2">完成任务解锁成就，获得奖励</p>
          </div>
          <div className="text-right">
            <div className="text-5xl font-bold">{unlockedCount}</div>
            <div className="text-sm opacity-90">/ {state.achievements.length}</div>
          </div>
        </div>
      </div>

      {/* 成就列表 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h3 className="text-xl font-bold text-gray-900 mb-6">📋 成就列表</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {state.achievements.map((achievement) => (
            <AchievementCard key={achievement.id} achievement={achievement} />
          ))}
        </div>
      </div>

      {/* 奖励统计 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h3 className="text-xl font-bold text-gray-900 mb-4">💎 奖励统计</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <StatCard
            label="已解锁成就"
            value={unlockedCount.toString()}
            color="from-green-50 to-green-100"
          />
          <StatCard
            label="待解锁成就"
            value={(state.achievements.length - unlockedCount).toString()}
            color="from-gray-50 to-gray-100"
          />
          <StatCard
            label="总奖励金额"
            value={`$${(state.achievements.filter(a => a.unlocked).reduce((sum, a) => sum + (a.reward || 0), 0) / 1000).toFixed(1)}K`}
            color="from-yellow-50 to-yellow-100"
          />
        </div>
      </div>
    </div>
  );
}

function AchievementCard({ achievement }: { achievement: any }) {
  return (
    <div
      className={`rounded-xl p-6 border-2 transition-all ${
        achievement.unlocked
          ? 'bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-300'
          : 'bg-gradient-to-br from-gray-50 to-gray-100 border-gray-300 opacity-60'
      }`}
    >
      <div className="flex justify-between items-start mb-3">
        <div className="text-4xl">{achievement.icon}</div>
        {achievement.unlocked && (
          <div className="bg-green-500 text-white px-2 py-1 rounded-full text-xs font-bold">
            ✓ 已解锁
          </div>
        )}
      </div>

      <h4 className="text-lg font-bold text-gray-900 mb-1">{achievement.name}</h4>
      <p className="text-sm text-gray-600 mb-3">{achievement.description}</p>

      {achievement.reward && (
        <div className="text-sm font-bold text-green-600 mb-2">
          奖励: ${(achievement.reward / 1000).toFixed(1)}K
        </div>
      )}

      {!achievement.unlocked && achievement.progress > 0 && (
        <div>
          <div className="flex justify-between items-center text-xs mb-1">
            <span className="text-gray-600">进度</span>
            <span className="font-bold text-gray-900">{achievement.progress}%</span>
          </div>
          <div className="w-full bg-gray-300 rounded-full h-2">
            <div
              className="bg-blue-500 h-2 rounded-full transition-all"
              style={{ width: `${achievement.progress}%` }}
            />
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({
  label,
  value,
  color,
}: {
  label: string;
  value: string;
  color: string;
}) {
  return (
    <div className={`bg-gradient-to-br ${color} rounded-xl p-4`}>
      <div className="text-sm text-gray-600 mb-2">{label}</div>
      <div className="text-2xl font-bold text-gray-900">{value}</div>
    </div>
  );
}
