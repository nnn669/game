import React from 'react';
import { useGame } from '@/contexts/GameContext';
import { formatMoney } from '@/lib/gameEngine';

export default function AnalyticsPanel() {
  const { state, totalAssets } = useGame();

  const winRate = state.totalTrades > 0 ? (state.winTrades / state.totalTrades) * 100 : 0;
  const avgProfit = state.totalTrades > 0 ? state.totalProfit / state.totalTrades : 0;
  const profitMargin = totalAssets > 0 ? (state.totalProfit / totalAssets) * 100 : 0;

  return (
    <div className="space-y-6">
      {/* 关键指标 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <MetricCard
          icon="📊"
          label="总交易数"
          value={state.totalTrades.toString()}
          color="from-blue-400 to-blue-600"
        />
        <MetricCard
          icon="✅"
          label="盈利笔数"
          value={state.winTrades.toString()}
          color="from-green-400 to-green-600"
        />
        <MetricCard
          icon="📈"
          label="胜率"
          value={`${winRate.toFixed(1)}%`}
          color="from-purple-400 to-purple-600"
        />
        <MetricCard
          icon="💰"
          label="平均利润"
          value={`$${formatMoney(avgProfit)}`}
          color="from-yellow-400 to-yellow-600"
        />
      </div>

      {/* 收益分析 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">💹 收益分析</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-6">
            <div className="text-sm text-gray-600 mb-2">总收益</div>
            <div className="text-3xl font-bold text-green-600">${formatMoney(state.totalProfit)}</div>
            <div className="text-xs text-gray-600 mt-2">
              收益率: {profitMargin.toFixed(2)}%
            </div>
          </div>
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-6">
            <div className="text-sm text-gray-600 mb-2">总资产</div>
            <div className="text-3xl font-bold text-blue-600">${formatMoney(totalAssets)}</div>
            <div className="text-xs text-gray-600 mt-2">
              初始资金: $5,000,000
            </div>
          </div>
          <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-6">
            <div className="text-sm text-gray-600 mb-2">最大回撤</div>
            <div className="text-3xl font-bold text-purple-600">{state.maxDrawdown.toFixed(2)}%</div>
            <div className="text-xs text-gray-600 mt-2">
              风险指标
            </div>
          </div>
        </div>
      </div>

      {/* 交易分布 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">📊 交易分布</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* 币种分布 */}
          <div>
            <h3 className="text-lg font-bold text-gray-900 mb-4">按币种分布</h3>
            <div className="space-y-3">
              {Object.entries(
                state.trades.reduce((acc: any, trade) => {
                  acc[trade.currencyId] = (acc[trade.currencyId] || 0) + 1;
                  return acc;
                }, {})
              ).map(([currency, count]) => (
                <div key={currency} className="flex justify-between items-center">
                  <span className="font-medium text-gray-900">{currency}</span>
                  <div className="flex items-center gap-2">
                    <div className="w-32 bg-gray-300 rounded-full h-2">
                      <div
                        className="bg-blue-500 h-2 rounded-full"
                        style={{ width: `${((count as number) / state.totalTrades) * 100}%` }}
                      />
                    </div>
                    <span className="text-sm text-gray-600 w-12 text-right">{String(count)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 交易类型分布 */}
          <div>
            <h3 className="text-lg font-bold text-gray-900 mb-4">按类型分布</h3>
            <div className="space-y-3">
              {[
                {
                  type: '买入',
                  count: state.trades.filter(t => t.type === 'buy').length,
                  color: 'bg-green-500',
                },
                {
                  type: '卖出',
                  count: state.trades.filter(t => t.type === 'sell').length,
                  color: 'bg-red-500',
                },
              ].map((item) => (
                <div key={item.type} className="flex justify-between items-center">
                  <span className="font-medium text-gray-900">{item.type}</span>
                  <div className="flex items-center gap-2">
                    <div className="w-32 bg-gray-300 rounded-full h-2">
                      <div
                        className={`${item.color} h-2 rounded-full`}
                        style={{ width: `${((item.count) / state.totalTrades) * 100}%` }}
                      />
                    </div>
                    <span className="text-sm text-gray-600 w-12 text-right">{item.count}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 时间统计 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">⏱️ 游戏统计</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard
            label="游戏时长"
            value={`${Math.floor((Date.now() - state.startTime) / 1000 / 60)} 分钟`}
            color="from-blue-50 to-blue-100"
          />
          <StatCard
            label="最后保存"
            value={new Date(state.lastSaveTime).toLocaleTimeString()}
            color="from-green-50 to-green-100"
          />
          <StatCard
            label="难度等级"
            value={state.difficulty === 'easy' ? '简单' : state.difficulty === 'normal' ? '普通' : '困难'}
            color="from-purple-50 to-purple-100"
          />
          <StatCard
            label="AI 状态"
            value={state.aiEnabled ? '启用' : '禁用'}
            color="from-yellow-50 to-yellow-100"
          />
        </div>
      </div>
    </div>
  );
}

function MetricCard({
  icon,
  label,
  value,
  color,
}: {
  icon: string;
  label: string;
  value: string;
  color: string;
}) {
  return (
    <div className={`bg-gradient-to-br ${color} rounded-2xl p-6 text-white shadow-lg`}>
      <div className="text-3xl mb-2">{icon}</div>
      <div className="text-sm font-medium opacity-90">{label}</div>
      <div className="text-2xl font-bold mt-2">{value}</div>
    </div>
  );
}

function StatCard({
  label,
  value,
  color,
}: {
  label: string;
  value: string;
  color: string;
}) {
  return (
    <div className={`bg-gradient-to-br ${color} rounded-xl p-4`}>
      <div className="text-sm text-gray-600 mb-2">{label}</div>
      <div className="text-lg font-bold text-gray-900">{value}</div>
    </div>
  );
}
