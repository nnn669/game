import React, { useState, useEffect } from 'react';
import { audioManager } from '@/lib/audioManager';

export default function AudioControl() {
  const [volume, setVolume] = useState(audioManager.getVolume());
  const [enabled, setEnabled] = useState(audioManager.getConfig().enabled);
  const [bgMusicEnabled, setBgMusicEnabled] = useState(
    audioManager.getConfig().backgroundMusicEnabled
  );
  const [soundEffectsEnabled, setSoundEffectsEnabled] = useState(
    audioManager.getConfig().soundEffectsEnabled
  );

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = Number(e.target.value);
    setVolume(newVolume);
    audioManager.setVolume(newVolume);
  };

  const handleEnabledChange = () => {
    const newEnabled = !enabled;
    setEnabled(newEnabled);
    audioManager.setEnabled(newEnabled);
  };

  const handleBgMusicChange = () => {
    const newBgMusicEnabled = !bgMusicEnabled;
    setBgMusicEnabled(newBgMusicEnabled);
    audioManager.setBackgroundMusicEnabled(newBgMusicEnabled);
  };

  const handleSoundEffectsChange = () => {
    const newSoundEffectsEnabled = !soundEffectsEnabled;
    setSoundEffectsEnabled(newSoundEffectsEnabled);
    audioManager.setSoundEffectsEnabled(newSoundEffectsEnabled);
  };

  const testSound = () => {
    audioManager.playSuccess();
  };

  return (
    <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
      <h3 className="text-xl font-bold text-gray-900 mb-6">🔊 音效设置</h3>

      <div className="space-y-6">
        {/* 总音量控制 */}
        <div>
          <div className="flex justify-between items-center mb-3">
            <label className="font-bold text-gray-900">总音量</label>
            <span className="text-sm font-bold text-blue-600">{Math.round(volume * 100)}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.1"
            value={volume}
            onChange={handleVolumeChange}
            className="w-full h-2 bg-gray-300 rounded-lg appearance-none cursor-pointer"
          />
          <div className="flex justify-between text-xs text-gray-600 mt-2">
            <span>静音</span>
            <span>最大</span>
          </div>
        </div>

        {/* 启用/禁用所有音效 */}
        <div className="flex items-center justify-between p-4 bg-gradient-to-r from-slate-50 to-slate-100 rounded-lg">
          <div>
            <div className="font-bold text-gray-900">启用所有音效</div>
            <div className="text-sm text-gray-600">打开/关闭所有音效和音乐</div>
          </div>
          <button
            onClick={handleEnabledChange}
            className={`relative inline-flex h-8 w-14 items-center rounded-full transition-colors ${
              enabled ? 'bg-green-500' : 'bg-gray-300'
            }`}
          >
            <span
              className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${
                enabled ? 'translate-x-7' : 'translate-x-1'
              }`}
            />
          </button>
        </div>

        {/* 背景音乐控制 */}
        <div className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg">
          <div>
            <div className="font-bold text-gray-900">🎵 背景音乐</div>
            <div className="text-sm text-gray-600">轻缓的环境音乐</div>
          </div>
          <button
            onClick={handleBgMusicChange}
            className={`relative inline-flex h-8 w-14 items-center rounded-full transition-colors ${
              bgMusicEnabled ? 'bg-green-500' : 'bg-gray-300'
            }`}
          >
            <span
              className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${
                bgMusicEnabled ? 'translate-x-7' : 'translate-x-1'
              }`}
            />
          </button>
        </div>

        {/* 音效控制 */}
        <div className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-purple-100 rounded-lg">
          <div>
            <div className="font-bold text-gray-900">🔔 界面音效</div>
            <div className="text-sm text-gray-600">按钮、交易、成就等音效</div>
          </div>
          <button
            onClick={handleSoundEffectsChange}
            className={`relative inline-flex h-8 w-14 items-center rounded-full transition-colors ${
              soundEffectsEnabled ? 'bg-green-500' : 'bg-gray-300'
            }`}
          >
            <span
              className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${
                soundEffectsEnabled ? 'translate-x-7' : 'translate-x-1'
              }`}
            />
          </button>
        </div>

        {/* 测试音效 */}
        <button
          onClick={testSound}
          className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold py-3 px-6 rounded-lg transition-all"
        >
          🔊 测试音效
        </button>

        {/* 音效说明 */}
        <div className="bg-gradient-to-r from-yellow-50 to-yellow-100 rounded-lg p-4">
          <h4 className="font-bold text-gray-900 mb-2">🎵 音效说明</h4>
          <ul className="text-sm text-gray-700 space-y-1">
            <li>• <strong>按钮音效</strong>：点击和悬停按钮时的音效</li>
            <li>• <strong>交易音效</strong>：买入/卖出时的音效</li>
            <li>• <strong>挖矿音效</strong>：启动/停止挖矿时的音效</li>
            <li>• <strong>成就音效</strong>：解锁成就时的音效</li>
            <li>• <strong>背景音乐</strong>：轻缓的环境音乐，可独立控制</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
