import React from 'react';
import { useGame } from '@/contexts/GameContext';

export default function EventStream({ limit = 20 }: { limit?: number }) {
  const { state } = useGame();

  const displayEvents = state.events.slice(0, limit);

  if (displayEvents.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="text-4xl mb-2">📭</div>
        <p className="text-gray-600">暂无事件</p>
      </div>
    );
  }

  return (
    <div className="space-y-3 max-h-96 overflow-y-auto">
      {displayEvents.map((event) => (
        <div
          key={event.id}
          className="flex gap-3 p-4 bg-gradient-to-r from-slate-50 to-slate-100 rounded-lg border-l-4"
          style={{ borderLeftColor: event.color }}
        >
          <div className="text-2xl flex-shrink-0">{event.icon}</div>
          <div className="flex-1 min-w-0">
            <div className="font-bold text-gray-900">{event.title}</div>
            <div className="text-sm text-gray-600">{event.description}</div>
            <div className="text-xs text-gray-500 mt-1">
              {new Date(event.timestamp).toLocaleTimeString()}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
