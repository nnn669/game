import React, { useState } from 'react';
import { useGame } from '@/contexts/GameContext';
import { formatMoney } from '@/lib/gameEngine';

interface Player {
  rank: number;
  name: string;
  totalAssets: number;
  profit: number;
  trades: number;
  achievements: number;
  winRate: number;
}

export default function Leaderboard() {
  const { state, totalAssets } = useGame();
  const [sortBy, setSortBy] = useState<'assets' | 'profit' | 'trades' | 'achievements'>('assets');

  // 模拟排行榜数据（实际应从服务器获取）
  const mockPlayers: Player[] = [
    {
      rank: 1,
      name: '加密大亨',
      totalAssets: 150000000,
      profit: 145000000,
      trades: 2500,
      achievements: 5,
      winRate: 68.5,
    },
    {
      rank: 2,
      name: '交易高手',
      totalAssets: 120000000,
      profit: 115000000,
      trades: 3200,
      achievements: 5,
      winRate: 65.2,
    },
    {
      rank: 3,
      name: '挖矿大师',
      totalAssets: 95000000,
      profit: 90000000,
      trades: 800,
      achievements: 4,
      winRate: 72.1,
    },
    {
      rank: 4,
      name: '投资者',
      totalAssets: 75000000,
      profit: 70000000,
      trades: 1200,
      achievements: 4,
      winRate: 61.3,
    },
    {
      rank: 5,
      name: '新手玩家',
      totalAssets: totalAssets,
      profit: state.totalProfit,
      trades: state.totalTrades,
      achievements: state.achievements.filter(a => a.unlocked).length,
      winRate: state.totalTrades > 0 ? (state.winTrades / state.totalTrades) * 100 : 0,
    },
  ];

  const sortedPlayers = [...mockPlayers].sort((a, b) => {
    switch (sortBy) {
      case 'assets':
        return b.totalAssets - a.totalAssets;
      case 'profit':
        return b.profit - a.profit;
      case 'trades':
        return b.trades - a.trades;
      case 'achievements':
        return b.achievements - a.achievements;
      default:
        return 0;
    }
  });

  const currentPlayerRank = sortedPlayers.findIndex(p => p.name === '新手玩家') + 1;

  return (
    <div className="space-y-6">
      {/* 当前排名 */}
      <div className="bg-gradient-to-br from-purple-500 to-purple-700 rounded-2xl p-8 text-white shadow-lg">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div>
            <div className="text-sm opacity-90">您的排名</div>
            <div className="text-5xl font-bold mt-2">#{currentPlayerRank}</div>
          </div>
          <div>
            <div className="text-sm opacity-90">总资产</div>
            <div className="text-3xl font-bold mt-2">${formatMoney(totalAssets)}</div>
          </div>
          <div>
            <div className="text-sm opacity-90">总收益</div>
            <div className="text-3xl font-bold mt-2">${formatMoney(state.totalProfit)}</div>
          </div>
          <div>
            <div className="text-sm opacity-90">胜率</div>
            <div className="text-3xl font-bold mt-2">
              {state.totalTrades > 0 ? ((state.winTrades / state.totalTrades) * 100).toFixed(1) : '0'}%
            </div>
          </div>
        </div>
      </div>

      {/* 排序选项 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">🏆 全球排行榜</h2>
        <div className="flex gap-2 flex-wrap mb-6">
          {[
            { id: 'assets', label: '按资产排序' },
            { id: 'profit', label: '按收益排序' },
            { id: 'trades', label: '按交易排序' },
            { id: 'achievements', label: '按成就排序' },
          ].map(option => (
            <button
              key={option.id}
              onClick={() => setSortBy(option.id as any)}
              className={`px-4 py-2 rounded-lg font-bold transition-all ${
                sortBy === option.id
                  ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg'
                  : 'bg-gradient-to-r from-slate-100 to-slate-200 text-gray-900 hover:shadow-md'
              }`}
            >
              {option.label}
            </button>
          ))}
        </div>

        {/* 排行榜表格 */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b-2 border-gray-300">
                <th className="text-left py-3 px-4 font-bold text-gray-900">排名</th>
                <th className="text-left py-3 px-4 font-bold text-gray-900">玩家</th>
                <th className="text-right py-3 px-4 font-bold text-gray-900">总资产</th>
                <th className="text-right py-3 px-4 font-bold text-gray-900">总收益</th>
                <th className="text-right py-3 px-4 font-bold text-gray-900">交易数</th>
                <th className="text-right py-3 px-4 font-bold text-gray-900">成就</th>
                <th className="text-right py-3 px-4 font-bold text-gray-900">胜率</th>
              </tr>
            </thead>
            <tbody>
              {sortedPlayers.map((player, index) => (
                <tr
                  key={index}
                  className={`border-b border-gray-200 hover:bg-blue-50 transition-colors ${
                    player.name === '新手玩家' ? 'bg-yellow-50' : ''
                  }`}
                >
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">
                        {index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : ''}
                      </span>
                      <span className="font-bold text-gray-900">#{index + 1}</span>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="font-bold text-gray-900">{player.name}</div>
                    {player.name === '新手玩家' && (
                      <div className="text-xs text-blue-600">（您）</div>
                    )}
                  </td>
                  <td className="py-4 px-4 text-right">
                    <div className="font-bold text-gray-900">${formatMoney(player.totalAssets)}</div>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <div className="font-bold text-green-600">${formatMoney(player.profit)}</div>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <div className="font-bold text-gray-900">{player.trades}</div>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <div className="flex items-center justify-end gap-1">
                      {Array.from({ length: player.achievements }).map((_, i) => (
                        <span key={i} className="text-lg">
                          🏆
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <div className="font-bold text-gray-900">{player.winRate.toFixed(1)}%</div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 分享成就 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">📢 分享成就</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {state.achievements
            .filter(a => a.unlocked)
            .map(achievement => (
              <ShareCard key={achievement.id} achievement={achievement} />
            ))}
        </div>
      </div>
    </div>
  );
}

function ShareCard({ achievement }: { achievement: any }) {
  const handleShare = () => {
    const text = `我在 CryptoSim Pro 中解锁了成就 "${achievement.name}"！🎉 获得奖励 $${(achievement.reward / 1000).toFixed(1)}K。来挑战我吧！`;
    if (navigator.share) {
      navigator.share({
        title: 'CryptoSim Pro',
        text: text,
      });
    } else {
      alert('分享链接: ' + text);
    }
  };

  return (
    <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-xl p-6 border-2 border-yellow-300">
      <div className="flex justify-between items-start mb-3">
        <div className="text-4xl">{achievement.icon}</div>
        <button
          onClick={handleShare}
          className="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded-lg text-sm font-bold transition-colors"
        >
          分享
        </button>
      </div>
      <h4 className="text-lg font-bold text-gray-900 mb-1">{achievement.name}</h4>
      <p className="text-sm text-gray-700 mb-2">{achievement.description}</p>
      <div className="text-sm font-bold text-green-600">
        奖励: ${(achievement.reward / 1000).toFixed(1)}K
      </div>
    </div>
  );
}
