import React from 'react';
import { useGame } from '@/contexts/GameContext';
import { formatPercent } from '@/lib/gameEngine';
import SoundButton from '@/components/SoundButton';

export default function MarketHub() {
  const { currencies, state } = useGame();

  return (
    <div className="space-y-6">
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">📈 实时行情</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {currencies.map(currency => (
            <div
              key={currency.id}
              className="bg-gradient-to-br from-slate-50 to-slate-100 rounded-xl p-6 hover:shadow-lg transition-shadow"
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-xl font-bold text-gray-900">{currency.symbol}</h3>
                  <p className="text-sm text-gray-600">{currency.name}</p>
                </div>
                <div
                  className={`text-2xl font-bold ${
                    currency.change24h > 0 ? 'text-green-600' : 'text-red-600'
                  }`}
                >
                  {formatPercent(currency.change24h)}
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">当前价格</span>
                  <span className="text-2xl font-bold text-gray-900">${currency.price.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-600">24h 高</span>
                  <span className="font-semibold text-gray-900">${currency.high24h.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-600">24h 低</span>
                  <span className="font-semibold text-gray-900">${currency.low24h.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-600">24h 成交量</span>
                  <span className="font-semibold text-gray-900">${(currency.volume24h / 1000000).toFixed(2)}M</span>
                </div>

                {/* 快速操作按马 */}
                <div className="flex gap-2 pt-2">
                  <SoundButton
                    onClick={() => {}}
                    variant="success"
                    soundType="trade"
                    size="sm"
                  >
                    🔻 买入
                  </SoundButton>
                  <SoundButton
                    onClick={() => {}}
                    variant="danger"
                    soundType="trade"
                    size="sm"
                  >
                    🔼 卖出
                  </SoundButton>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 市场统计 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h3 className="text-xl font-bold text-gray-900 mb-4">📊 市场统计</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard
            label="涨幅最大"
            value={Math.max(...currencies.map(c => c.change24h)).toFixed(2) + '%'}
            color="text-green-600"
          />
          <StatCard
            label="跌幅最大"
            value={Math.min(...currencies.map(c => c.change24h)).toFixed(2) + '%'}
            color="text-red-600"
          />
          <StatCard
            label="总成交量"
            value={`$${(currencies.reduce((sum, c) => sum + c.volume24h, 0) / 1000000000).toFixed(2)}B`}
            color="text-blue-600"
          />
          <StatCard
            label="持仓币种"
            value={Object.keys(state.portfolio).length.toString()}
            color="text-purple-600"
          />
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="bg-gradient-to-br from-slate-50 to-slate-100 rounded-xl p-4">
      <div className="text-sm text-gray-600 mb-2">{label}</div>
      <div className={`text-2xl font-bold ${color}`}>{value}</div>
    </div>
  );
}
