import React, { useState } from 'react';
import { useGame } from '@/contexts/GameContext';
import SoundButton from '@/components/SoundButton';
import { formatMoney } from '@/lib/gameEngine';

export default function MiningEngine() {
  const { state, dispatch, toggleMining, expandDevice, unlockDevice } = useGame();;

  const handleExpandChange = (device: string, value: number): void => {
    dispatch({ type: 'UPDATE_EXPAND_PERCENT', payload: { device, percent: value } });
  };

  return (
    <div className="space-y-6">
      {/* 挖矿概览 */}
      <div className="bg-gradient-to-br from-green-400 to-emerald-600 rounded-2xl p-8 text-white shadow-lg">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div>
            <div className="text-sm opacity-90">状态</div>
            <div className="text-3xl font-bold mt-2">{state.mining.active ? '运行中' : '已停止'}</div>
          </div>
          <div>
            <div className="text-sm opacity-90">总算力</div>
            <div className="text-3xl font-bold mt-2">{state.mining.totalHashrate.toFixed(0)}</div>
            <div className="text-xs opacity-75">H/s</div>
          </div>
          <div>
            <div className="text-sm opacity-90">电费/秒</div>
            <div className="text-3xl font-bold mt-2">${formatMoney(state.mining.powerCostPerSecond)}</div>
          </div>
          <div>
            <div className="text-sm opacity-90">BTC产出/小时</div>
            <div className="text-3xl font-bold mt-2">{(state.mining.btcPerSecond * 3600).toFixed(6)}</div>
          </div>
        </div>

        <button
          onClick={toggleMining}
          className={`mt-6 w-full py-3 px-6 rounded-lg font-bold text-lg transition-all ${
            state.mining.active
              ? 'bg-red-500 hover:bg-red-600'
              : 'bg-green-500 hover:bg-green-600'
          }`}
        >
          {state.mining.active ? '⏹️ 停止挖矿' : '▶️ 启动挖矿'}
        </button>
      </div>

      {/* 矿机列表 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">⛏️ 矿机管理</h2>
        <div className="space-y-4">
          {Object.entries(state.mining.devices).map(([key, device]) => (
            <MiningDeviceCard
              key={key}
              deviceKey={key}
              device={device}
              cash={state.cash}
              expandPercent={state.expandPercent[key]}
              onExpandChange={(value) => handleExpandChange(key, value)}
              onExpand={() => expandDevice(key)}
              onUnlock={() => unlockDevice(key)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function MiningDeviceCard({
  deviceKey,
  device,
  cash,
  expandPercent,
  onExpandChange,
  onExpand,
  onUnlock,
}: {
  deviceKey: string;
  device: any;
  cash: number;
  expandPercent: number;
  onExpandChange: (value: number) => void;
  onExpand: () => void;
  onUnlock: () => void;
}) {
  const canUnlock = !device.unlocked && cash >= device.unlockCost;
  const expandCount = Math.floor((expandPercent / 100) * 100);
  const expandCost = expandCount * device.upgradeCost;
  const canExpand = device.unlocked && cash >= expandCost;

  return (
    <div className="bg-gradient-to-br from-slate-50 to-slate-100 rounded-xl p-6 border border-slate-200">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-xl font-bold text-gray-900">{device.name}</h3>
          <p className="text-sm text-gray-600">已拥有: {device.count} 台</p>
        </div>
        {device.unlocked && (
          <span className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-bold">
            已解锁
          </span>
        )}
      </div>

      <div className="grid grid-cols-3 gap-4 mb-4 text-sm">
        <div>
          <span className="text-gray-600">算力</span>
          <div className="font-bold text-gray-900">{device.hashrate} H/s</div>
        </div>
        <div>
          <span className="text-gray-600">电费</span>
          <div className="font-bold text-gray-900">${device.power}/s</div>
        </div>
        <div>
          <span className="text-gray-600">解锁费用</span>
          <div className="font-bold text-gray-900">${formatMoney(device.unlockCost)}</div>
        </div>
      </div>

      {!device.unlocked ? (
            <SoundButton
              onClick={() => onUnlock()}
              disabled={!canUnlock}
              variant="primary"
              soundType="success"
            >
              🔓 解锁
            </SoundButton>
      ) : (
        <div className="space-y-3">
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-sm font-medium text-gray-700">扩建百分比</label>
              <span className="text-sm font-bold text-blue-600">{expandPercent}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={expandPercent}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => onExpandChange(Number(e.target.value))}
              className="w-full h-2 bg-gray-300 rounded-lg appearance-none cursor-pointer"
            />
            <div className="text-xs text-gray-600 mt-1">
              扩建 {expandCount} 台，总费用: ${formatMoney(expandCost)}
            </div>
          </div>
            <SoundButton
              onClick={() => onExpand()}
              disabled={!canExpand}
              variant="success"
              soundType="mining"
            >
              ✅ 扩建
            </SoundButton>
        </div>
      )}
    </div>
  );
}
