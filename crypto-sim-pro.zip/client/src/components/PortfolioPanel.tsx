import React from 'react';
import { useGame } from '@/contexts/GameContext';
import { formatMoney, formatPercent } from '@/lib/gameEngine';

export default function PortfolioPanel() {
  const { state, currencies, totalAssets, buy, sell } = useGame();

  const portfolioValue = Object.entries(state.portfolio).map(([currencyId, holding]) => {
    const currency = currencies.find(c => c.id === currencyId);
    if (!currency) return null;
    const value = holding.qty * currency.price;
    const profit = value - holding.qty * holding.avgCost;
    const profitPercent = (profit / (holding.qty * holding.avgCost)) * 100;
    return { currencyId, holding, currency, value, profit, profitPercent };
  }).filter(Boolean);

  return (
    <div className="space-y-6">
      {/* 资产分布 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">💼 资产分布</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-4">
            <div className="text-sm text-gray-600 mb-1">现金</div>
            <div className="text-lg font-bold text-gray-900">${formatMoney(state.cash)}</div>
            <div className="text-xs text-gray-600 mt-1">{((state.cash / totalAssets) * 100).toFixed(1)}%</div>
          </div>
          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-4">
            <div className="text-sm text-gray-600 mb-1">持仓价值</div>
            <div className="text-lg font-bold text-gray-900">
              ${formatMoney(portfolioValue.reduce((sum, p) => sum + (p?.value || 0), 0))}
            </div>
            <div className="text-xs text-gray-600 mt-1">
              {((portfolioValue.reduce((sum, p) => sum + (p?.value || 0), 0) / totalAssets) * 100).toFixed(1)}%
            </div>
          </div>
          <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-4">
            <div className="text-sm text-gray-600 mb-1">总收益</div>
            <div className={`text-lg font-bold ${state.totalProfit > 0 ? 'text-green-600' : 'text-red-600'}`}>
              ${formatMoney(state.totalProfit)}
            </div>
            <div className="text-xs text-gray-600 mt-1">
              {((state.totalProfit / totalAssets) * 100).toFixed(1)}%
            </div>
          </div>
          <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-xl p-4">
            <div className="text-sm text-gray-600 mb-1">持仓币种</div>
            <div className="text-lg font-bold text-gray-900">{Object.keys(state.portfolio).length}</div>
            <div className="text-xs text-gray-600 mt-1">种</div>
          </div>
        </div>
      </div>

      {/* 持仓详情 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">📊 持仓详情</h2>
        {portfolioValue.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-4xl mb-2">📭</div>
            <p className="text-gray-600">还没有持仓，去行情页面买入吧！</p>
          </div>
        ) : (
          <div className="space-y-4">
            {portfolioValue.map((item) => (
              <div
                key={item?.currencyId}
                className="bg-gradient-to-br from-slate-50 to-slate-100 rounded-xl p-6 border border-slate-200"
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">{item?.currency?.symbol}</h3>
                    <p className="text-sm text-gray-600">{item?.currency?.name}</p>
                  </div>
                  <div className="text-right">
                    <div className={`text-2xl font-bold ${item?.profit! > 0 ? 'text-green-600' : 'text-red-600'}`}>
                      ${formatMoney(item?.value || 0)}
                    </div>
                    <div className={`text-sm font-bold ${item?.profitPercent! > 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {item?.profitPercent! > 0 ? '+' : ''}{item?.profitPercent?.toFixed(2)}%
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-4 text-sm mb-4">
                  <div>
                    <span className="text-gray-600">数量</span>
                    <div className="font-bold text-gray-900">{item?.holding?.qty.toFixed(6)}</div>
                  </div>
                  <div>
                    <span className="text-gray-600">成本价</span>
                    <div className="font-bold text-gray-900">${item?.holding?.avgCost.toFixed(2)}</div>
                  </div>
                  <div>
                    <span className="text-gray-600">当前价</span>
                    <div className="font-bold text-gray-900">${item?.currency?.price.toFixed(2)}</div>
                  </div>
                  <div>
                    <span className="text-gray-600">收益</span>
                    <div className={`font-bold ${item?.profit! > 0 ? 'text-green-600' : 'text-red-600'}`}>
                      ${formatMoney(item?.profit || 0)}
                    </div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button className="flex-1 bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-lg transition-colors">
                    加仓
                  </button>
                  <button className="flex-1 bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded-lg transition-colors">
                    减仓
                  </button>
                  <button className="flex-1 bg-orange-500 hover:bg-orange-600 text-white font-bold py-2 px-4 rounded-lg transition-colors">
                    止损
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
