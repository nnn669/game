import React, { useMemo } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { useGame } from '@/contexts/GameContext';
import { generatePriceHistory, getChartColors } from '@/lib/chartUtils';

export default function PriceChart() {
  const { currencies } = useGame();

  const chartData = useMemo(() => {
    return generatePriceHistory(currencies, 24);
  }, [currencies]);

  const colors = getChartColors();

  return (
    <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">📈 价格走势</h2>

      <ResponsiveContainer width="100%" height={400}>
        <LineChart data={chartData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis
            dataKey="time"
            stroke="#6b7280"
            style={{ fontSize: '12px' }}
          />
          <YAxis
            stroke="#6b7280"
            style={{ fontSize: '12px' }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: 'rgba(255, 255, 255, 0.95)',
              border: '1px solid #e2e8f0',
              borderRadius: '8px',
            }}
            formatter={(value: any) => `$${value.toFixed(2)}`}
          />
          <Legend />

          {currencies.map((currency) => (
            <Line
              key={currency.id}
              type="monotone"
              dataKey={currency.symbol}
              stroke={colors[currency.symbol] || '#3b82f6'}
              dot={false}
              isAnimationActive={false}
              strokeWidth={2}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-5 gap-4">
        {currencies.map((currency) => (
          <div
            key={currency.id}
            className="bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg p-4"
          >
            <div className="flex items-center gap-2 mb-2">
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: colors[currency.symbol] }}
              />
              <span className="font-bold text-gray-900">{currency.symbol}</span>
            </div>
            <div className="text-lg font-bold text-gray-900">${currency.price.toFixed(2)}</div>
            <div
              className={`text-sm font-bold ${
                currency.change24h > 0 ? 'text-green-600' : 'text-red-600'
              }`}
            >
              {currency.change24h > 0 ? '+' : ''}{currency.change24h.toFixed(2)}%
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
