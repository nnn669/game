import React, { useMemo } from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { useGame } from '@/contexts/GameContext';
import { generateProfitHistory, getChartColors } from '@/lib/chartUtils';
import { formatMoney } from '@/lib/gameEngine';

export default function ProfitChart() {
  const { state, currencies } = useGame();

  const chartData = useMemo(() => {
    return generateProfitHistory(state, currencies, 24);
  }, [state, currencies]);

  const colors = getChartColors();

  return (
    <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">📊 收益曲线</h2>

      <ResponsiveContainer width="100%" height={400}>
        <AreaChart data={chartData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
          <defs>
            <linearGradient id="colorAssets" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={colors.profit} stopOpacity={0.8} />
              <stop offset="95%" stopColor={colors.profit} stopOpacity={0} />
            </linearGradient>
            <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8} />
              <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis
            dataKey="time"
            stroke="#6b7280"
            style={{ fontSize: '12px' }}
          />
          <YAxis
            stroke="#6b7280"
            style={{ fontSize: '12px' }}
            tickFormatter={(value) => `$${(value / 1000000).toFixed(1)}M`}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: 'rgba(255, 255, 255, 0.95)',
              border: '1px solid #e2e8f0',
              borderRadius: '8px',
            }}
            formatter={(value: any) => `$${formatMoney(value)}`}
          />
          <Legend />

          <Area
            type="monotone"
            dataKey="totalAssets"
            stroke={colors.profit}
            fillOpacity={1}
            fill="url(#colorAssets)"
            name="总资产"
            isAnimationActive={false}
          />
          <Area
            type="monotone"
            dataKey="profit"
            stroke="#3b82f6"
            fillOpacity={1}
            fill="url(#colorProfit)"
            name="总收益"
            isAnimationActive={false}
          />
        </AreaChart>
      </ResponsiveContainer>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4">
          <div className="text-sm text-gray-600 mb-2">总资产</div>
          <div className="text-2xl font-bold text-green-600">
            ${formatMoney(chartData[chartData.length - 1]?.totalAssets || 0)}
          </div>
        </div>
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4">
          <div className="text-sm text-gray-600 mb-2">总收益</div>
          <div className="text-2xl font-bold text-blue-600">
            ${formatMoney(chartData[chartData.length - 1]?.profit || 0)}
          </div>
        </div>
        <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-4">
          <div className="text-sm text-gray-600 mb-2">收益率</div>
          <div className="text-2xl font-bold text-purple-600">
            {(
              ((chartData[chartData.length - 1]?.profit || 0) / 5000000) *
              100
            ).toFixed(2)}
            %
          </div>
        </div>
      </div>
    </div>
  );
}
