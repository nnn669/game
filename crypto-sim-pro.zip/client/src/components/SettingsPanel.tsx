import React from 'react';
import { useGame } from '@/contexts/GameContext';
import { initializeGameState, saveGameState } from '@/lib/gameEngine';
import AudioControl from '@/components/AudioControl';

export default function SettingsPanel() {
  const { state, dispatch } = useGame();

  const handleReset = () => {
    if (window.confirm('确定要重置游戏吗？所有数据将被清除！')) {
      const newState = initializeGameState();
      dispatch({ type: 'SET_STATE', payload: newState });
      saveGameState(newState);
    }
  };

  const handleExport = () => {
    const dataStr = JSON.stringify(state, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `cryptosim-export-${Date.now()}.json`;
    link.click();
  };

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const importedState = JSON.parse(e.target?.result as string);
        dispatch({ type: 'SET_STATE', payload: importedState });
        saveGameState(importedState);
        alert('导入成功！');
      } catch (error) {
        alert('导入失败，文件格式错误');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      {/* 游戏设置 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">⚙️ 游戏设置</h2>

        {/* 难度设置 */}
        <div className="mb-8">
          <h3 className="text-lg font-bold text-gray-900 mb-4">🎯 难度等级</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { id: 'easy', label: '简单', description: '初始资金多，利率低' },
              { id: 'normal', label: '普通', description: '平衡的游戏体验' },
              { id: 'hard', label: '困难', description: '初始资金少，利率高' },
            ].map((difficulty) => (
              <button
                key={difficulty.id}
                className={`p-4 rounded-xl transition-all text-left ${
                  state.difficulty === difficulty.id
                    ? 'bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-lg'
                    : 'bg-gradient-to-br from-slate-50 to-slate-100 text-gray-900 hover:shadow-md'
                }`}
              >
                <div className="font-bold">{difficulty.label}</div>
                <div className={`text-sm ${state.difficulty === difficulty.id ? 'opacity-90' : 'text-gray-600'}`}>
                  {difficulty.description}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* 游戏参数 */}
        <div className="mb-8">
          <h3 className="text-lg font-bold text-gray-900 mb-4">📊 游戏参数</h3>
          <div className="space-y-4">
            <SettingRow
              label="初始资金"
              value="$5,000,000"
              description="游戏开始时的初始现金"
            />
            <SettingRow
              label="AI 交易间隔"
              value={`${state.aiTradeInterval / 1000} 秒`}
              description="AI 自动交易的执行间隔"
            />
            <SettingRow
              label="挖矿更新频率"
              value="1 秒"
              description="挖矿产出的更新频率"
            />
            <SettingRow
              label="市场更新频率"
              value="2 秒"
              description="市场价格的更新频率"
            />
          </div>
        </div>
      </div>

      {/* 数据管理 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">💾 数据管理</h2>
        <div className="space-y-4">
          <button
            onClick={handleExport}
            className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-bold py-3 px-6 rounded-lg transition-all"
          >
            📥 导出游戏数据
          </button>
          <label className="block">
            <button className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold py-3 px-6 rounded-lg transition-all">
              📤 导入游戏数据
            </button>
            <input
              type="file"
              accept=".json"
              onChange={handleImport}
              className="hidden"
            />
          </label>
          <button
            onClick={handleReset}
            className="w-full bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-bold py-3 px-6 rounded-lg transition-all"
          >
            🔄 重置游戏
          </button>
        </div>
      </div>

      {/* 音效设置 */}
      <AudioControl />

      {/* 关于游戏 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">ℹ️ 关于游戏</h2>
        <div className="space-y-4 text-gray-700">
          <div>
            <h3 className="font-bold text-gray-900 mb-2">游戏简介</h3>
            <p>CryptoSim Pro 是一个虚拟币交易与挖矿模拟系统，让您在安全的环境中学习和实践加密货币交易策略。</p>
          </div>
          <div>
            <h3 className="font-bold text-gray-900 mb-2">核心功能</h3>
            <ul className="list-disc list-inside space-y-1">
              <li>📈 实时行情中心 - 查看 5 种虚拟币的实时价格</li>
              <li>⛏️ 智能挖矿系统 - 4 层矿机升级，逐级解锁</li>
              <li>🤖 AI 自动交易 - 三种风险模式可选</li>
              <li>💼 资产管理面板 - 完整的持仓和收益统计</li>
              <li>🏆 成就系统 - 完成任务解锁成就获得奖励</li>
              <li>📊 数据分析 - 详细的交易和收益分析</li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-gray-900 mb-2">游戏目标</h3>
            <p>通过挖矿、交易和投资，将初始资金 500 万增长到 1 亿，成为顶级交易者！</p>
          </div>
          <div>
            <h3 className="font-bold text-gray-900 mb-2">版本信息</h3>
            <p>CryptoSim Pro v1.0.0 | 最后更新: 2026-03-06</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SettingRow({
  label,
  value,
  description,
}: {
  label: string;
  value: string;
  description: string;
}) {
  return (
    <div className="flex justify-between items-start p-4 bg-gradient-to-r from-slate-50 to-slate-100 rounded-lg">
      <div>
        <div className="font-bold text-gray-900">{label}</div>
        <div className="text-sm text-gray-600">{description}</div>
      </div>
      <div className="text-right">
        <div className="font-bold text-gray-900">{value}</div>
      </div>
    </div>
  );
}
