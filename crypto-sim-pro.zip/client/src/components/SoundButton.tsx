import React from 'react';
import { audioManager } from '@/lib/audioManager';

interface SoundButtonProps {
  onClick: () => void;
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'danger' | 'success';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  soundType?: 'click' | 'success' | 'error' | 'trade' | 'mining' | 'achievement';
  className?: string;
}

export default function SoundButton({
  onClick,
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  soundType = 'click',
  className = '',
}: SoundButtonProps) {
  const handleClick = () => {
    if (disabled) return;

    // 播放相应的音效
    switch (soundType) {
      case 'success':
        audioManager.playSuccess();
        break;
      case 'error':
        audioManager.playError();
        break;
      case 'trade':
        audioManager.playTradeSuccess();
        break;
      case 'mining':
        audioManager.playMining();
        break;
      case 'achievement':
        audioManager.playAchievementUnlock();
        break;
      default:
        audioManager.playButtonClick();
    }

    onClick();
  };

  const handleMouseEnter = () => {
    if (!disabled) {
      audioManager.playButtonHover();
    }
  };

  const variantClasses = {
    primary: 'bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white',
    secondary: 'bg-gradient-to-r from-slate-100 to-slate-200 hover:from-slate-200 hover:to-slate-300 text-gray-900',
    danger: 'bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white',
    success: 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white',
  };

  const sizeClasses = {
    sm: 'px-3 py-1 text-sm',
    md: 'px-4 py-2 text-base',
    lg: 'px-6 py-3 text-lg',
  };

  return (
    <button
      onClick={handleClick}
      onMouseEnter={handleMouseEnter}
      disabled={disabled}
      className={`
        ${variantClasses[variant]}
        ${sizeClasses[size]}
        font-bold
        rounded-lg
        transition-all
        active:scale-95
        disabled:opacity-50
        disabled:cursor-not-allowed
        ${className}
      `}
    >
      {children}
    </button>
  );
}
