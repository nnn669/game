import React, { useMemo, useState } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { useGame } from '@/contexts/GameContext';
import { generatePriceHistory, calculateTechnicalIndicators, getChartColors } from '@/lib/chartUtils';

export default function TechnicalAnalysis() {
  const { currencies } = useGame();
  const [selectedCurrency, setSelectedCurrency] = useState(currencies[0]?.id || 'BTC');

  const selectedCurrencyData = currencies.find(c => c.id === selectedCurrency);

  const chartData = useMemo(() => {
    const priceHistory = generatePriceHistory(currencies, 50);
    const prices = priceHistory.map(p => (p[selectedCurrency] as number) || 0);
    const indicators = calculateTechnicalIndicators(prices);

    return priceHistory.map((point, index) => ({
      ...point,
      ma20: indicators.ma20[index],
      ma50: indicators.ma50[index],
      rsi: indicators.rsi[index],
    }));
  }, [currencies, selectedCurrency]);

  const colors = getChartColors();

  return (
    <div className="space-y-6">
      {/* 币种选择 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">🔍 技术分析</h2>
        <div className="flex gap-2 flex-wrap">
          {currencies.map(currency => (
            <button
              key={currency.id}
              onClick={() => setSelectedCurrency(currency.id)}
              className={`px-4 py-2 rounded-lg font-bold transition-all ${
                selectedCurrency === currency.id
                  ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg'
                  : 'bg-gradient-to-r from-slate-100 to-slate-200 text-gray-900 hover:shadow-md'
              }`}
            >
              {currency.symbol}
            </button>
          ))}
        </div>
      </div>

      {/* 价格与移动平均线 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h3 className="text-xl font-bold text-gray-900 mb-4">📈 价格与移动平均线</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis
              dataKey="time"
              stroke="#6b7280"
              style={{ fontSize: '12px' }}
            />
            <YAxis
              stroke="#6b7280"
              style={{ fontSize: '12px' }}
              tickFormatter={(value) => `$${value.toFixed(0)}`}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: 'rgba(255, 255, 255, 0.95)',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
              }}
              formatter={(value: any) => `$${value.toFixed(2)}`}
            />
            <Legend />

            <Line
              type="monotone"
              dataKey={selectedCurrency}
              stroke="#000"
              dot={false}
              isAnimationActive={false}
              strokeWidth={2}
              name="价格"
            />
            <Line
              type="monotone"
              dataKey="ma20"
              stroke={colors.ma20}
              dot={false}
              isAnimationActive={false}
              strokeWidth={1.5}
              strokeDasharray="5 5"
              name="MA20"
            />
            <Line
              type="monotone"
              dataKey="ma50"
              stroke={colors.ma50}
              dot={false}
              isAnimationActive={false}
              strokeWidth={1.5}
              strokeDasharray="5 5"
              name="MA50"
            />
          </LineChart>
        </ResponsiveContainer>

        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          <IndicatorCard
            label="当前价格"
            value={`$${selectedCurrencyData?.price.toFixed(2)}`}
            color="from-gray-50 to-gray-100"
          />
          <IndicatorCard
            label="MA20"
            value={`$${(
              chartData[chartData.length - 1]?.ma20 || selectedCurrencyData?.price || 0
            ).toFixed(2)}`}
            color="from-blue-50 to-blue-100"
          />
          <IndicatorCard
            label="MA50"
            value={`$${(
              chartData[chartData.length - 1]?.ma50 || selectedCurrencyData?.price || 0
            ).toFixed(2)}`}
            color="from-purple-50 to-purple-100"
          />
        </div>
      </div>

      {/* RSI 指标 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h3 className="text-xl font-bold text-gray-900 mb-4">📊 RSI 相对强弱指数</h3>
        <ResponsiveContainer width="100%" height={250}>
          <LineChart data={chartData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis
              dataKey="time"
              stroke="#6b7280"
              style={{ fontSize: '12px' }}
            />
            <YAxis
              stroke="#6b7280"
              style={{ fontSize: '12px' }}
              domain={[0, 100]}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: 'rgba(255, 255, 255, 0.95)',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
              }}
              formatter={(value: any) => value.toFixed(2)}
            />
            <Legend />

            <Line
              type="monotone"
              dataKey="rsi"
              stroke={colors.rsi}
              dot={false}
              isAnimationActive={false}
              strokeWidth={2}
              name="RSI(14)"
            />
          </LineChart>
        </ResponsiveContainer>

        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          <IndicatorCard
            label="RSI 值"
            value={(chartData[chartData.length - 1]?.rsi || 50).toFixed(2)}
            color="from-pink-50 to-pink-100"
          />
          <IndicatorCard
            label="超买区"
            value="> 70"
            color="from-red-50 to-red-100"
          />
          <IndicatorCard
            label="超卖区"
            value="< 30"
            color="from-green-50 to-green-100"
          />
        </div>

        <div className="mt-4 p-4 bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg">
          <p className="text-sm text-gray-700">
            <strong>RSI 解读：</strong> RSI 在 0-100 之间波动。当 RSI &gt; 70 时，表示超买（可能回调）；当 RSI &lt; 30 时，表示超卖（可能反弹）。
          </p>
        </div>
      </div>

      {/* 交易建议 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h3 className="text-xl font-bold text-gray-900 mb-4">💡 交易建议</h3>
        <div className="space-y-3">
          <SuggestionCard
            title="移动平均线策略"
            description="当价格在 MA20 上方时看涨，在 MA20 下方时看跌。MA20 穿过 MA50 时可能是趋势转折点。"
            color="from-blue-50 to-blue-100"
          />
          <SuggestionCard
            title="RSI 超买超卖"
            description="RSI > 70 时可能出现回调，考虑减仓；RSI < 30 时可能出现反弹，考虑加仓。"
            color="from-pink-50 to-pink-100"
          />
          <SuggestionCard
            title="风险管理"
            description="永远设置止损点，通常在关键支撑位下方 2-3%。不要过度杠杆，风险控制在总资金的 2% 以内。"
            color="from-yellow-50 to-yellow-100"
          />
        </div>
      </div>
    </div>
  );
}

function IndicatorCard({
  label,
  value,
  color,
}: {
  label: string;
  value: string;
  color: string;
}) {
  return (
    <div className={`bg-gradient-to-br ${color} rounded-lg p-4`}>
      <div className="text-sm text-gray-600 mb-2">{label}</div>
      <div className="text-xl font-bold text-gray-900">{value}</div>
    </div>
  );
}

function SuggestionCard({
  title,
  description,
  color,
}: {
  title: string;
  description: string;
  color: string;
}) {
  return (
    <div className={`bg-gradient-to-br ${color} rounded-lg p-4`}>
      <h4 className="font-bold text-gray-900 mb-2">{title}</h4>
      <p className="text-sm text-gray-700">{description}</p>
    </div>
  );
}
