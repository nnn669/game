import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import { GameState, Currency } from '@/types/game';
import {
  initializeGameState,
  initializeMarketData,
  updateMarketPrices,
  calculateTotalAssets,
  executeBuy,
  executeSell,
  toggleMining,
  expandDevice,
  unlockDevice,
  recalculateMining,
  checkAchievements,
  saveGameState,
  loadGameState,
} from '@/lib/gameEngine';

interface GameContextType {
  state: GameState;
  currencies: Currency[];
  totalAssets: number;
  dispatch: (action: GameAction) => void;
  // 便捷方法
  buy: (currencyId: string, qty: number, price: number) => boolean;
  sell: (currencyId: string, qty: number, price: number) => boolean;
  toggleMining: () => void;
  expandDevice: (deviceKey: string) => boolean;
  unlockDevice: (deviceKey: string) => boolean;
}

export interface GameAction {
  type: string;
  payload?: any;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

export function GameProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(gameReducer, null, () => {
    const saved = loadGameState();
    return saved || initializeGameState();
  });

  const [currencies, setCurrencies] = React.useState<Currency[]>(() => initializeMarketData());

  const totalAssets = calculateTotalAssets(state, currencies);

  // 定期更新市场价格
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrencies(prev => updateMarketPrices(prev));
    }, 2000); // 每 2 秒更新一次

    return () => clearInterval(interval);
  }, []);

  // 定期保存游戏状态
  useEffect(() => {
    const interval = setInterval(() => {
      saveGameState(state);
    }, 5000); // 每 5 秒保存一次

    return () => clearInterval(interval);
  }, [state]);

  // 定期运行挖矿
  useEffect(() => {
    if (!state.mining.active) return;

    const interval = setInterval(() => {
      dispatch({ type: 'MINING_TICK' });
    }, 1000); // 每秒更新一次

    return () => clearInterval(interval);
  }, [state.mining.active, state.mining.btcPerSecond]);

  // 定期运行 AI 交易
  useEffect(() => {
    if (!state.aiEnabled) return;

    const interval = setInterval(() => {
      dispatch({ type: 'AI_TRADE_TICK' });
    }, state.aiTradeInterval);

    return () => clearInterval(interval);
  }, [state.aiEnabled, state.aiTradeInterval, state.aiMode]);

  // 检查成就
  useEffect(() => {
    checkAchievements(state, currencies);
  }, [totalAssets, state.totalTrades]);

  const buy = useCallback(
    (currencyId: string, qty: number, price: number): boolean => {
      const result = executeBuy(state, currencyId, qty, price, 'manual');
      if (result.success && result.newState) {
        dispatch({ type: 'SET_STATE', payload: result.newState });
        return true;
      }
      return false;
    },
    [state]
  );

  const sell = useCallback(
    (currencyId: string, qty: number, price: number): boolean => {
      const result = executeSell(state, currencyId, qty, price, 'manual');
      if (result.success && result.newState) {
        dispatch({ type: 'SET_STATE', payload: result.newState });
        return true;
      }
      return false;
    },
    [state]
  );

  const handleToggleMining = useCallback(() => {
    const newState = toggleMining(state);
    dispatch({ type: 'SET_STATE', payload: newState });
  }, [state]);

  const handleExpandDevice = useCallback(
    (deviceKey: string): boolean => {
      const result = expandDevice(state, deviceKey);
      if (result.success && result.newState) {
        dispatch({ type: 'SET_STATE', payload: result.newState });
        return true;
      }
      return false;
    },
    [state]
  );

  const handleUnlockDevice = useCallback(
    (deviceKey: string): boolean => {
      const result = unlockDevice(state, deviceKey);
      if (result.success && result.newState) {
        dispatch({ type: 'SET_STATE', payload: result.newState });
        return true;
      }
      return false;
    },
    [state]
  );

  const value: GameContextType = {
    state,
    currencies,
    totalAssets,
    dispatch,
    buy,
    sell,
    toggleMining: handleToggleMining,
    expandDevice: handleExpandDevice,
    unlockDevice: handleUnlockDevice,
  };

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
}

export function useGame() {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGame must be used within GameProvider');
  }
  return context;
}

function gameReducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case 'SET_STATE':
      return action.payload;

    case 'MINING_TICK': {
      const newState = { ...state };
      if (newState.mining.active && newState.mining.btcPerSecond > 0) {
        const btcGain = newState.mining.btcPerSecond;
        const powerCost = newState.mining.powerCostPerSecond;

        if (!newState.portfolio['BTC']) {
          newState.portfolio['BTC'] = { qty: 0, avgCost: 0 };
        }
        newState.portfolio['BTC'].qty += btcGain;
        newState.cash -= powerCost;

        // 如果现金不足，停止挖矿
        if (newState.cash < 0) {
          newState.mining.active = false;
          newState.mining.shutdownCountdown = 0;
        }
      }
      return newState;
    }

    case 'AI_TRADE_TICK': {
      const newState = { ...state };
      // AI 交易逻辑（简化版）
      if (newState.aiEnabled) {
        // 这里可以添加更复杂的 AI 逻辑
      }
      return newState;
    }

    case 'TOGGLE_AI':
      return { ...state, aiEnabled: !state.aiEnabled };

    case 'SET_AI_MODE':
      return { ...state, aiMode: action.payload };

    case 'UPDATE_EXPAND_PERCENT':
      return {
        ...state,
        expandPercent: {
          ...state.expandPercent,
          [action.payload.device]: action.payload.percent,
        },
      };

    default:
      return state;
  }
}
