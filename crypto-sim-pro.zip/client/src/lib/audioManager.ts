/**
 * 音效管理系统
 * 负责管理游戏中的所有音效和背景音乐
 */

export interface AudioConfig {
  volume: number; // 0-1
  enabled: boolean;
  backgroundMusicEnabled: boolean;
  soundEffectsEnabled: boolean;
}

class AudioManager {
  private audioContext: AudioContext | null = null;
  private backgroundMusic: HTMLAudioElement | null = null;
  private soundEffects: Map<string, HTMLAudioElement> = new Map();
  private config: AudioConfig = {
    volume: 0.5,
    enabled: true,
    backgroundMusicEnabled: true,
    soundEffectsEnabled: true,
  };

  constructor() {
    this.initAudioContext();
    this.loadConfig();
  }

  private initAudioContext() {
    try {
      const audioContextClass = (window as any).AudioContext || (window as any).webkitAudioContext;
      this.audioContext = new audioContextClass();
    } catch (e) {
      console.warn('AudioContext not supported');
    }
  }

  private loadConfig() {
    const saved = localStorage.getItem('audioConfig');
    if (saved) {
      this.config = { ...this.config, ...JSON.parse(saved) };
    }
  }

  private saveConfig() {
    localStorage.setItem('audioConfig', JSON.stringify(this.config));
  }

  // 初始化背景音乐
  initBackgroundMusic() {
    if (this.backgroundMusic) return;

    this.backgroundMusic = new Audio();
    this.backgroundMusic.loop = true;
    this.backgroundMusic.volume = this.config.volume * 0.3; // 背景音乐音量较低
    // 使用 Web Audio API 合成的简单背景音乐
    // 实际应用中应该使用真实的音频文件
  }

  // 播放背景音乐
  playBackgroundMusic() {
    if (!this.config.enabled || !this.config.backgroundMusicEnabled) return;

    // 由于浏览器限制，这里使用 Web Audio API 合成音乐
    this.synthesizeBackgroundMusic();
  }

  // 停止背景音乐
  stopBackgroundMusic() {
    if (this.backgroundMusic) {
      this.backgroundMusic.pause();
      this.backgroundMusic.currentTime = 0;
    }
  }

  // 使用 Web Audio API 合成背景音乐
  private synthesizeBackgroundMusic() {
    if (!this.audioContext) return;

    const ctx = this.audioContext;
    const now = ctx.currentTime;

    // 创建一个简单的环境音乐效果
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);

    // 设置音量
    gainNode.gain.setValueAtTime(this.config.volume * 0.1, now);

    // 创建舒缓的音调
    oscillator.frequency.setValueAtTime(220, now); // A3 note
    oscillator.frequency.exponentialRampToValueAtTime(440, now + 4);

    oscillator.start(now);
    oscillator.stop(now + 4);
  }

  // 播放按钮点击音效
  playButtonClick() {
    if (!this.config.enabled || !this.config.soundEffectsEnabled) return;
    this.playTone(800, 0.1, 0.1);
  }

  // 播放按钮悬停音效
  playButtonHover() {
    if (!this.config.enabled || !this.config.soundEffectsEnabled) return;
    this.playTone(600, 0.05, 0.05);
  }

  // 播放成功音效
  playSuccess() {
    if (!this.config.enabled || !this.config.soundEffectsEnabled) return;
    this.playTone(1000, 0.15, 0.2);
    setTimeout(() => this.playTone(1200, 0.15, 0.2), 100);
  }

  // 播放错误音效
  playError() {
    if (!this.config.enabled || !this.config.soundEffectsEnabled) return;
    this.playTone(300, 0.15, 0.2);
    setTimeout(() => this.playTone(250, 0.15, 0.2), 100);
  }

  // 播放交易成功音效
  playTradeSuccess() {
    if (!this.config.enabled || !this.config.soundEffectsEnabled) return;
    this.playTone(880, 0.1, 0.15);
    setTimeout(() => this.playTone(1100, 0.1, 0.15), 80);
    setTimeout(() => this.playTone(1320, 0.1, 0.15), 160);
  }

  // 播放挖矿音效
  playMining() {
    if (!this.config.enabled || !this.config.soundEffectsEnabled) return;
    this.playTone(440, 0.1, 0.1);
    setTimeout(() => this.playTone(550, 0.1, 0.1), 100);
  }

  // 播放成就解锁音效
  playAchievementUnlock() {
    if (!this.config.enabled || !this.config.soundEffectsEnabled) return;
    // 播放一个上升的音调序列
    const frequencies = [523, 659, 784, 1047]; // C5, E5, G5, C6
    frequencies.forEach((freq, index) => {
      setTimeout(() => this.playTone(freq, 0.15, 0.2), index * 150);
    });
  }

  // 播放警告音效
  playWarning() {
    if (!this.config.enabled || !this.config.soundEffectsEnabled) return;
    this.playTone(700, 0.1, 0.15);
    setTimeout(() => this.playTone(700, 0.1, 0.15), 200);
  }

  // 使用 Web Audio API 播放单个音调
  private playTone(frequency: number, duration: number, volume: number) {
    if (!this.audioContext) return;

    const ctx = this.audioContext;
    const now = ctx.currentTime;

    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);

    oscillator.frequency.setValueAtTime(frequency, now);
    oscillator.type = 'sine';

    // 设置音量包络
    gainNode.gain.setValueAtTime(0, now);
    gainNode.gain.linearRampToValueAtTime(this.config.volume * volume, now + 0.01);
    gainNode.gain.exponentialRampToValueAtTime(0.01, now + duration);

    oscillator.start(now);
    oscillator.stop(now + duration);
  }

  // 设置音量
  setVolume(volume: number) {
    this.config.volume = Math.max(0, Math.min(1, volume));
    this.saveConfig();

    if (this.backgroundMusic) {
      this.backgroundMusic.volume = this.config.volume * 0.3;
    }
  }

  // 获取当前音量
  getVolume(): number {
    return this.config.volume;
  }

  // 启用/禁用所有音效
  setEnabled(enabled: boolean) {
    this.config.enabled = enabled;
    this.saveConfig();
  }

  // 启用/禁用背景音乐
  setBackgroundMusicEnabled(enabled: boolean) {
    this.config.backgroundMusicEnabled = enabled;
    this.saveConfig();
    if (!enabled) {
      this.stopBackgroundMusic();
    }
  }

  // 启用/禁用音效
  setSoundEffectsEnabled(enabled: boolean) {
    this.config.soundEffectsEnabled = enabled;
    this.saveConfig();
  }

  // 获取配置
  getConfig(): AudioConfig {
    return { ...this.config };
  }

  // 恢复默认设置
  resetConfig() {
    this.config = {
      volume: 0.5,
      enabled: true,
      backgroundMusicEnabled: true,
      soundEffectsEnabled: true,
    };
    this.saveConfig();
  }
}

// 导出单例
export const audioManager = new AudioManager();
