import { GameState, Currency } from '@/types/game';

// 价格历史数据点
export interface PriceDataPoint {
  timestamp: number;
  time: string;
  [key: string]: number | string; // 币种价格
}

// 收益曲线数据点
export interface ProfitDataPoint {
  timestamp: number;
  time: string;
  totalAssets: number;
  profit: number;
  cash: number;
}

// 技术分析指标
export interface TechnicalIndicators {
  ma20: number[];
  ma50: number[];
  rsi: number[];
  macd: {
    macdLine: number[];
    signalLine: number[];
    histogram: number[];
  };
}

// 生成价格历史数据（模拟）
export function generatePriceHistory(
  currencies: Currency[],
  points: number = 24
): PriceDataPoint[] {
  const now = Date.now();
  const data: PriceDataPoint[] = [];

  for (let i = points - 1; i >= 0; i--) {
    const timestamp = now - i * 3600000; // 每小时一个数据点
    const time = new Date(timestamp).toLocaleTimeString('zh-CN', {
      hour: '2-digit',
      minute: '2-digit',
    });

    const point: PriceDataPoint = {
      timestamp,
      time,
    };

    // 为每个币种生成价格数据（加入随机波动）
    currencies.forEach(currency => {
      const volatility = 0.05; // 5% 波动
      const change = (Math.random() - 0.5) * volatility * 2;
      point[currency.symbol] = Math.round(currency.price * (1 + change) * 100) / 100;
    });

    data.push(point);
  }

  return data;
}

// 生成收益曲线数据
export function generateProfitHistory(
  state: GameState,
  currencies: Currency[],
  points: number = 24
): ProfitDataPoint[] {
  const now = Date.now();
  const initialAssets = 5000000;
  const data: ProfitDataPoint[] = [];

  for (let i = points - 1; i >= 0; i--) {
    const timestamp = now - i * 3600000;
    const time = new Date(timestamp).toLocaleTimeString('zh-CN', {
      hour: '2-digit',
      minute: '2-digit',
    });

    // 模拟资产增长曲线
    const growthRate = 0.02; // 每小时增长 2%
    const totalAssets = initialAssets * Math.pow(1 + growthRate, points - i);
    const profit = totalAssets - initialAssets;
    const cash = state.cash;

    data.push({
      timestamp,
      time,
      totalAssets: Math.round(totalAssets),
      profit: Math.round(profit),
      cash: Math.round(cash),
    });
  }

  return data;
}

// 计算移动平均线 (MA)
export function calculateMA(prices: number[], period: number): number[] {
  const ma: number[] = [];

  for (let i = 0; i < prices.length; i++) {
    if (i < period - 1) {
      ma.push(NaN);
    } else {
      const sum = prices.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
      ma.push(sum / period);
    }
  }

  return ma;
}

// 计算相对强弱指数 (RSI)
export function calculateRSI(prices: number[], period: number = 14): number[] {
  const rsi: number[] = [];
  const changes = [];

  for (let i = 1; i < prices.length; i++) {
    changes.push(prices[i] - prices[i - 1]);
  }

  for (let i = 0; i < prices.length; i++) {
    if (i < period) {
      rsi.push(NaN);
    } else {
      const gains = changes
        .slice(i - period, i)
        .filter(c => c > 0)
        .reduce((a, b) => a + b, 0);
      const losses = Math.abs(
        changes
          .slice(i - period, i)
          .filter(c => c < 0)
          .reduce((a, b) => a + b, 0)
      );

      const avgGain = gains / period;
      const avgLoss = losses / period;
      const rs = avgGain / avgLoss;
      const rsiValue = 100 - 100 / (1 + rs);

      rsi.push(isNaN(rsiValue) ? 50 : rsiValue);
    }
  }

  return rsi;
}

// 计算 MACD
export function calculateMACD(
  prices: number[]
): {
  macdLine: number[];
  signalLine: number[];
  histogram: number[];
} {
  const ema12 = calculateEMA(prices, 12);
  const ema26 = calculateEMA(prices, 26);

  const macdLine = ema12.map((val, i) => (isNaN(val) || isNaN(ema26[i]) ? NaN : val - ema26[i]));

  const signalLine = calculateEMA(macdLine.filter(v => !isNaN(v)), 9);
  const histogram = macdLine.map((val, i) => (isNaN(val) || isNaN(signalLine[i]) ? NaN : val - signalLine[i]));

  return { macdLine, signalLine, histogram };
}

// 计算指数移动平均线 (EMA)
function calculateEMA(prices: number[], period: number): number[] {
  const ema: number[] = [];
  const k = 2 / (period + 1);

  let sma = 0;
  for (let i = 0; i < period && i < prices.length; i++) {
    sma += prices[i];
  }
  sma /= period;

  ema[period - 1] = sma;

  for (let i = period; i < prices.length; i++) {
    const emaValue = prices[i] * k + ema[i - 1] * (1 - k);
    ema[i] = emaValue;
  }

  return ema;
}

// 计算技术指标
export function calculateTechnicalIndicators(prices: number[]): TechnicalIndicators {
  return {
    ma20: calculateMA(prices, 20),
    ma50: calculateMA(prices, 50),
    rsi: calculateRSI(prices, 14),
    macd: calculateMACD(prices),
  };
}

// 格式化图表数据
export function formatChartData(data: any[], keys: string[]): any[] {
  return data.map(item => {
    const formatted: any = {
      time: item.time || item.timestamp,
    };

    keys.forEach(key => {
      if (item[key] !== undefined) {
        formatted[key] = Math.round(item[key] * 100) / 100;
      }
    });

    return formatted;
  });
}

// 获取图表颜色
export function getChartColors(): { [key: string]: string } {
  return {
    BTC: '#F7931A',
    ETH: '#627EEA',
    XRP: '#23292F',
    ADA: '#0033AD',
    SOL: '#14F195',
    profit: '#2ed573',
    loss: '#ff4757',
    ma20: '#3b82f6',
    ma50: '#8b5cf6',
    rsi: '#ec4899',
    macd: '#06b6d4',
  };
}
