import { GameState, Currency, Portfolio, Trade, Event, Achievement, MiningState } from '@/types/game';

// 初始化游戏状态
export function initializeGameState(): GameState {
  const now = Date.now();
  return {
    cash: 5000000,
    bankDeposit: 0,
    loanAmount: 0,
    loanPrincipal: 0,
    portfolio: {},
    mining: initializeMiningState(),
    trades: [],
    loans: [],
    aiEnabled: false,
    aiMode: 'balanced',
    aiLastTradeTime: now,
    aiTradeInterval: 10000, // 10秒
    achievements: initializeAchievements(),
    events: [],
    totalProfit: 0,
    totalTrades: 0,
    winTrades: 0,
    maxDrawdown: 0,
    difficulty: 'normal',
    startTime: now,
    lastSaveTime: now,
    expandPercent: {
      entry: 0,
      pro: 0,
      main: 0,
      asic: 0,
    },
  };
}

function initializeMiningState(): MiningState {
  return {
    active: false,
    totalHashrate: 0,
    powerCostPerSecond: 0,
    btcPerSecond: 0,
    devices: {
      entry: {
        name: '入门矿机',
        hashrate: 100,
        power: 10,
        unlockCost: 50000,
        upgradeCost: 5000,
        count: 0,
        unlocked: true,
      },
      pro: {
        name: '专业矿机',
        hashrate: 500,
        power: 50,
        unlockCost: 500000,
        upgradeCost: 50000,
        count: 0,
        unlocked: false,
      },
      main: {
        name: '主流矿机',
        hashrate: 2000,
        power: 200,
        unlockCost: 2000000,
        upgradeCost: 200000,
        count: 0,
        unlocked: false,
      },
      asic: {
        name: 'ASIC矿机',
        hashrate: 10000,
        power: 1000,
        unlockCost: 10000000,
        upgradeCost: 1000000,
        count: 0,
        unlocked: false,
      },
    },
    shutdownCountdown: 0,
  };
}

function initializeAchievements(): Achievement[] {
  return [
    {
      id: 'first_trade',
      name: '初出茅庐',
      description: '完成第一笔交易',
      icon: '🎯',
      unlocked: false,
      progress: 0,
      reward: 100000,
    },
    {
      id: 'millionaire',
      name: '百万富翁',
      description: '资产突破 100 万',
      icon: '💰',
      unlocked: false,
      progress: 0,
      reward: 500000,
    },
    {
      id: 'mining_master',
      name: '挖矿大师',
      description: '解锁所有矿机',
      icon: '⛏️',
      unlocked: false,
      progress: 0,
      reward: 1000000,
    },
    {
      id: 'trading_streak',
      name: '连胜高手',
      description: '连续 10 笔盈利交易',
      icon: '🔥',
      unlocked: false,
      progress: 0,
      reward: 500000,
    },
    {
      id: 'diversified',
      name: '资产多元化',
      description: '持有 5 种不同币种',
      icon: '🌈',
      unlocked: false,
      progress: 0,
      reward: 300000,
    },
  ];
}

// 初始化市场数据
export function initializeMarketData(): Currency[] {
  return [
    {
      id: 'BTC',
      name: 'Bitcoin',
      symbol: 'BTC',
      price: 45000,
      change24h: 2.5,
      high24h: 46000,
      low24h: 43000,
      volume24h: 1000000000,
    },
    {
      id: 'ETH',
      name: 'Ethereum',
      symbol: 'ETH',
      price: 2500,
      change24h: 1.8,
      high24h: 2600,
      low24h: 2400,
      volume24h: 500000000,
    },
    {
      id: 'XRP',
      name: 'Ripple',
      symbol: 'XRP',
      price: 2.5,
      change24h: -0.5,
      high24h: 2.6,
      low24h: 2.3,
      volume24h: 300000000,
    },
    {
      id: 'ADA',
      name: 'Cardano',
      symbol: 'ADA',
      price: 0.95,
      change24h: 3.2,
      high24h: 0.98,
      low24h: 0.92,
      volume24h: 200000000,
    },
    {
      id: 'SOL',
      name: 'Solana',
      symbol: 'SOL',
      price: 180,
      change24h: 4.1,
      high24h: 185,
      low24h: 175,
      volume24h: 400000000,
    },
  ];
}

// 更新市场价格（模拟波动）
export function updateMarketPrices(currencies: Currency[]): Currency[] {
  return currencies.map(c => {
    const volatility = 0.02; // 2% 波动
    const change = (Math.random() - 0.5) * volatility;
    const newPrice = c.price * (1 + change);
    const newChange24h = c.change24h + (Math.random() - 0.5) * 0.5;
    
    return {
      ...c,
      price: Math.max(newPrice, c.price * 0.5), // 防止价格过低
      change24h: Math.max(-20, Math.min(20, newChange24h)),
      high24h: Math.max(c.high24h, newPrice),
      low24h: Math.min(c.low24h, newPrice),
    };
  });
}

// 计算总资产
export function calculateTotalAssets(state: GameState, currencies: Currency[]): number {
  let total = state.cash + state.bankDeposit;
  
  for (const [currencyId, holding] of Object.entries(state.portfolio)) {
    const currency = currencies.find(c => c.id === currencyId);
    if (currency) {
      total += holding.qty * currency.price;
    }
  }
  
  return total;
}

// 执行买入操作
export function executeBuy(
  state: GameState,
  currencyId: string,
  qty: number,
  price: number,
  source: 'manual' | 'ai' = 'manual'
): { success: boolean; message: string; newState?: GameState } {
  const total = qty * price;
  
  if (state.cash < total) {
    return { success: false, message: '资金不足' };
  }
  
  const newState = { ...state };
  newState.cash -= total;
  
  if (!newState.portfolio[currencyId]) {
    newState.portfolio[currencyId] = { qty: 0, avgCost: 0 };
  }
  
  const holding = newState.portfolio[currencyId];
  const totalQty = holding.qty + qty;
  holding.avgCost = (holding.qty * holding.avgCost + total) / totalQty;
  holding.qty = totalQty;
  
  const trade: Trade = {
    id: `trade_${Date.now()}`,
    timestamp: Date.now(),
    type: 'buy',
    currencyId,
    qty,
    price,
    total,
    source,
  };
  
  newState.trades.push(trade);
  newState.totalTrades++;
  
  addEvent(newState, {
    type: 'trade',
    title: `买入 ${qty.toFixed(4)} ${currencyId}`,
    description: `价格: $${price.toFixed(2)}, 总额: $${total.toFixed(2)}`,
    color: '#2ed573',
  });
  
  return { success: true, message: '买入成功', newState };
}

// 执行卖出操作
export function executeSell(
  state: GameState,
  currencyId: string,
  qty: number,
  price: number,
  source: 'manual' | 'ai' = 'manual'
): { success: boolean; message: string; newState?: GameState } {
  const holding = state.portfolio[currencyId];
  
  if (!holding || holding.qty < qty) {
    return { success: false, message: '持仓不足' };
  }
  
  const newState = { ...state };
  const total = qty * price;
  const profit = total - qty * holding.avgCost;
  
  newState.cash += total;
  holding.qty -= qty;
  
  if (holding.qty === 0) {
    delete newState.portfolio[currencyId];
  }
  
  const trade: Trade = {
    id: `trade_${Date.now()}`,
    timestamp: Date.now(),
    type: 'sell',
    currencyId,
    qty,
    price,
    total,
    source,
  };
  
  newState.trades.push(trade);
  newState.totalTrades++;
  
  if (profit > 0) {
    newState.winTrades++;
    newState.totalProfit += profit;
  }
  
  addEvent(newState, {
    type: 'trade',
    title: `卖出 ${qty.toFixed(4)} ${currencyId}`,
    description: `价格: $${price.toFixed(2)}, 收益: $${profit.toFixed(2)}`,
    color: profit > 0 ? '#2ed573' : '#ff4757',
  });
  
  return { success: true, message: '卖出成功', newState };
}

// 启动/停止挖矿
export function toggleMining(state: GameState): GameState {
  const newState = { ...state };
  newState.mining.active = !newState.mining.active;
  
  if (newState.mining.active) {
    addEvent(newState, {
      type: 'mining',
      title: '挖矿已启动',
      description: `总算力: ${newState.mining.totalHashrate} H/s`,
      color: '#11998e',
    });
  } else {
    addEvent(newState, {
      type: 'mining',
      title: '挖矿已停止',
      description: '矿机已关闭',
      color: '#ff4757',
    });
  }
  
  return newState;
}

// 扩建矿机
export function expandDevice(
  state: GameState,
  deviceKey: string
): { success: boolean; message: string; newState?: GameState } {
  const device = state.mining.devices[deviceKey as keyof typeof state.mining.devices];
  const expandCount = Math.floor((state.expandPercent[deviceKey] / 100) * 100);
  const cost = expandCount * device.upgradeCost;
  
  if (state.cash < cost) {
    return { success: false, message: '资金不足' };
  }
  
  const newState = { ...state };
  newState.cash -= cost;
  device.count += expandCount;
  newState.expandPercent[deviceKey] = 0;
  
  recalculateMining(newState);
  
  addEvent(newState, {
    type: 'mining',
    title: `${device.name}扩建完成`,
    description: `新增 ${expandCount} 台，总数: ${device.count}`,
    color: '#3b82f6',
  });
  
  return { success: true, message: '扩建成功', newState };
}

// 解锁矿机
export function unlockDevice(
  state: GameState,
  deviceKey: string
): { success: boolean; message: string; newState?: GameState } {
  const device = state.mining.devices[deviceKey as keyof typeof state.mining.devices];
  
  if (device.unlocked) {
    return { success: false, message: '已解锁' };
  }
  
  if (state.cash < device.unlockCost) {
    return { success: false, message: '资金不足' };
  }
  
  const newState = { ...state };
  newState.cash -= device.unlockCost;
  device.unlocked = true;
  
  addEvent(newState, {
    type: 'mining',
    title: `解锁 ${device.name}`,
    description: `花费: $${device.unlockCost.toLocaleString()}`,
    color: '#764ba2',
  });
  
  return { success: true, message: '解锁成功', newState };
}

// 重新计算挖矿参数
export function recalculateMining(state: GameState): void {
  let totalHashrate = 0;
  let totalPower = 0;
  
  for (const device of Object.values(state.mining.devices)) {
    if (device.unlocked) {
      totalHashrate += device.hashrate * device.count;
      totalPower += device.power * device.count;
    }
  }
  
  state.mining.totalHashrate = totalHashrate;
  state.mining.powerCostPerSecond = totalPower;
  
  // 计算 BTC 产出（简化模型）
  const btcPerHashPerSecond = 0.000000001;
  state.mining.btcPerSecond = totalHashrate * btcPerHashPerSecond;
}

// 添加事件
export function addEvent(
  state: GameState,
  event: Partial<Event>
): void {
  const newEvent: Event = {
    id: `event_${Date.now()}`,
    timestamp: Date.now(),
    type: event.type as any,
    title: event.title || '',
    description: event.description || '',
    icon: event.icon || '📌',
    color: event.color || '#999',
    data: event.data,
  };
  
  state.events.unshift(newEvent);
  
  // 保持事件列表在 100 条以内
  if (state.events.length > 100) {
    state.events.pop();
  }
}

// 检查成就
export function checkAchievements(state: GameState, currencies: Currency[]): void {
  const totalAssets = calculateTotalAssets(state, currencies);
  
  // 检查百万富翁成就
  const millionaireAch = state.achievements.find(a => a.id === 'millionaire');
  if (millionaireAch && !millionaireAch.unlocked && totalAssets >= 1000000) {
    millionaireAch.unlocked = true;
    millionaireAch.unlockedAt = Date.now();
    state.cash += millionaireAch.reward || 0;
    addEvent(state, {
      type: 'achievement',
      title: `🏆 解锁成就: ${millionaireAch.name}`,
      description: `获得奖励: $${millionaireAch.reward?.toLocaleString()}`,
      color: '#ffd700',
    });
  }
  
  // 检查初出茅庐成就
  const firstTradeAch = state.achievements.find(a => a.id === 'first_trade');
  if (firstTradeAch && !firstTradeAch.unlocked && state.totalTrades > 0) {
    firstTradeAch.unlocked = true;
    firstTradeAch.unlockedAt = Date.now();
    state.cash += firstTradeAch.reward || 0;
  }
  
  // 检查多元化成就
  const diversifiedAch = state.achievements.find(a => a.id === 'diversified');
  if (diversifiedAch && !diversifiedAch.unlocked && Object.keys(state.portfolio).length >= 5) {
    diversifiedAch.unlocked = true;
    diversifiedAch.unlockedAt = Date.now();
    state.cash += diversifiedAch.reward || 0;
  }
}

// 保存游戏状态
export function saveGameState(state: GameState): void {
  const saveData = {
    ...state,
    lastSaveTime: Date.now(),
  };
  localStorage.setItem('cryptosim_gamestate', JSON.stringify(saveData));
}

// 加载游戏状态
export function loadGameState(): GameState | null {
  const data = localStorage.getItem('cryptosim_gamestate');
  if (data) {
    try {
      return JSON.parse(data);
    } catch (e) {
      console.error('Failed to load game state:', e);
      return null;
    }
  }
  return null;
}

// 格式化货币
export function formatMoney(value: number): string {
  if (value >= 1000000) {
    return (value / 1000000).toFixed(2) + 'M';
  }
  if (value >= 1000) {
    return (value / 1000).toFixed(2) + 'K';
  }
  return value.toFixed(2);
}

// 格式化百分比
export function formatPercent(value: number): string {
  return (value > 0 ? '+' : '') + value.toFixed(2) + '%';
}
