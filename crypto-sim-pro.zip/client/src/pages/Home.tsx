import React, { useState } from 'react';
import { useGame } from '@/contexts/GameContext';
import { formatMoney, formatPercent } from '@/lib/gameEngine';
import MarketHub from '@/components/MarketHub';
import MiningEngine from '@/components/MiningEngine';
import PortfolioPanel from '@/components/PortfolioPanel';
import AITrading from '@/components/AITrading';
import EventStream from '@/components/EventStream';
import AchievementPanel from '@/components/AchievementPanel';
import AnalyticsPanel from '@/components/AnalyticsPanel';
import SettingsPanel from '@/components/SettingsPanel';
import PriceChart from '@/components/PriceChart';
import ProfitChart from '@/components/ProfitChart';
import TechnicalAnalysis from '@/components/TechnicalAnalysis';
import Leaderboard from '@/components/Leaderboard';

type ViewType = 'market' | 'mining' | 'portfolio' | 'ai' | 'achievements' | 'analytics' | 'settings' | 'dashboard' | 'charts' | 'technical' | 'leaderboard';

export default function Home() {
  const { state, totalAssets } = useGame();
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');

  const renderView = () => {
    switch (currentView) {
      case 'market':
        return <MarketHub />;
      case 'mining':
        return <MiningEngine />;
      case 'portfolio':
        return <PortfolioPanel />;
      case 'ai':
        return <AITrading />;
      case 'achievements':
        return <AchievementPanel />;
      case 'analytics':
        return <AnalyticsPanel />;
      case 'settings':
        return <SettingsPanel />;
      case 'charts':
        return (
          <div className="space-y-6">
            <PriceChart />
            <ProfitChart />
          </div>
        );
      case 'technical':
        return <TechnicalAnalysis />;
      case 'leaderboard':
        return <Leaderboard />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* 顶部导航 */}
      <header className="sticky top-0 z-40 backdrop-blur-md bg-white/80 border-b border-white/20">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="text-3xl">💰</div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">CryptoSim Pro</h1>
                <p className="text-sm text-gray-600">虚拟币交易挖矿模拟系统</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-600">总资产</div>
              <div className="text-2xl font-bold text-green-600">${formatMoney(totalAssets)}</div>
            </div>
          </div>
        </div>
      </header>

      {/* 主内容区 */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {renderView()}
      </main>

      {/* 底部导航栏 */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-md border-t border-white/20">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex justify-around items-center py-3 overflow-x-auto">
            <NavButton
              icon="📊"
              label="仪表板"
              active={currentView === 'dashboard'}
              onClick={() => setCurrentView('dashboard')}
            />
            <NavButton
              icon="📈"
              label="行情"
              active={currentView === 'market'}
              onClick={() => setCurrentView('market')}
            />
            <NavButton
              icon="⛏️"
              label="挖矿"
              active={currentView === 'mining'}
              onClick={() => setCurrentView('mining')}
            />
            <NavButton
              icon="💼"
              label="资产"
              active={currentView === 'portfolio'}
              onClick={() => setCurrentView('portfolio')}
            />
            <NavButton
              icon="🤖"
              label="AI交易"
              active={currentView === 'ai'}
              onClick={() => setCurrentView('ai')}
            />
            <NavButton
              icon="🏆"
              label="成就"
              active={currentView === 'achievements'}
              onClick={() => setCurrentView('achievements')}
            />
            <NavButton
              icon="📊"
              label="分析"
              active={currentView === 'analytics'}
              onClick={() => setCurrentView('analytics')}
            />
            <NavButton
              icon="⚙️"
              label="设置"
              active={currentView === 'settings'}
              onClick={() => setCurrentView('settings')}
            />
            <NavButton
              icon="📉"
              label="图表"
              active={currentView === 'charts'}
              onClick={() => setCurrentView('charts')}
            />
            <NavButton
              icon="🔬"
              label="技术"
              active={currentView === 'technical'}
              onClick={() => setCurrentView('technical')}
            />
            <NavButton
              icon="🏅"
              label="排行"
              active={currentView === 'leaderboard'}
              onClick={() => setCurrentView('leaderboard')}
            />
          </div>
        </div>
      </nav>

      {/* 内容底部间距 */}
      <div className="h-24" />
    </div>
  );
}

function DashboardView() {
  const { state, currencies, totalAssets } = useGame();

  const topCurrencies = currencies.slice(0, 3);
  const unlockedAchievements = state.achievements.filter(a => a.unlocked).length;

  return (
    <div className="space-y-6">
      {/* 关键指标卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <MetricCard
          icon="💰"
          label="现金余额"
          value={`$${formatMoney(state.cash)}`}
          color="from-blue-400 to-blue-600"
        />
        <MetricCard
          icon="💎"
          label="总资产"
          value={`$${formatMoney(totalAssets)}`}
          color="from-green-400 to-green-600"
        />
        <MetricCard
          icon="📈"
          label="总收益"
          value={`$${formatMoney(state.totalProfit)}`}
          color="from-purple-400 to-purple-600"
        />
        <MetricCard
          icon="🏆"
          label="成就进度"
          value={`${unlockedAchievements}/${state.achievements.length}`}
          color="from-yellow-400 to-yellow-600"
        />
      </div>

      {/* 行情速览 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h2 className="text-xl font-bold text-gray-900 mb-4">📈 行情速览</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {topCurrencies.map(currency => (
            <div key={currency.id} className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl p-4">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <div className="font-bold text-gray-900">{currency.symbol}</div>
                  <div className="text-sm text-gray-600">{currency.name}</div>
                </div>
                <div className={`text-sm font-bold ${currency.change24h > 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatPercent(currency.change24h)}
                </div>
              </div>
              <div className="text-lg font-bold text-gray-900">${currency.price.toFixed(2)}</div>
            </div>
          ))}
        </div>
      </div>

      {/* 挖矿状态 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h2 className="text-xl font-bold text-gray-900 mb-4">⛏️ 挖矿状态</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-4">
            <div className="text-sm text-gray-600 mb-1">状态</div>
            <div className="text-lg font-bold text-green-600">{state.mining.active ? '运行中' : '已停止'}</div>
          </div>
          <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl p-4">
            <div className="text-sm text-gray-600 mb-1">总算力</div>
            <div className="text-lg font-bold text-blue-600">{state.mining.totalHashrate.toFixed(0)} H/s</div>
          </div>
          <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-xl p-4">
            <div className="text-sm text-gray-600 mb-1">电费/秒</div>
            <div className="text-lg font-bold text-orange-600">${formatMoney(state.mining.powerCostPerSecond)}</div>
          </div>
          <div className="bg-gradient-to-br from-yellow-50 to-amber-50 rounded-xl p-4">
            <div className="text-sm text-gray-600 mb-1">BTC产出</div>
            <div className="text-lg font-bold text-yellow-600">{(state.mining.btcPerSecond * 3600).toFixed(6)}/h</div>
          </div>
        </div>
      </div>

      {/* 最近事件 */}
      <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h2 className="text-xl font-bold text-gray-900 mb-4">📌 最近事件</h2>
        <EventStream limit={5} />
      </div>
    </div>
  );
}

function MetricCard({
  icon,
  label,
  value,
  color,
}: {
  icon: string;
  label: string;
  value: string;
  color: string;
}) {
  return (
    <div className={`bg-gradient-to-br ${color} rounded-2xl p-6 text-white shadow-lg`}>
      <div className="text-3xl mb-2">{icon}</div>
      <div className="text-sm font-medium opacity-90">{label}</div>
      <div className="text-2xl font-bold mt-2">{value}</div>
    </div>
  );
}

function NavButton({
  icon,
  label,
  active,
  onClick,
}: {
  icon: string;
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-all whitespace-nowrap ${
        active
          ? 'bg-gradient-to-br from-blue-500 to-purple-500 text-white shadow-lg'
          : 'text-gray-600 hover:text-gray-900'
      }`}
    >
      <span className="text-xl">{icon}</span>
      <span className="text-xs font-medium">{label}</span>
    </button>
  );
}
