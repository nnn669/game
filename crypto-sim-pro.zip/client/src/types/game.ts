// 游戏状态类型定义

export interface Currency {
  id: string;
  name: string;
  symbol: string;
  price: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24h: number;
}

export interface Portfolio {
  [currencyId: string]: {
    qty: number;
    avgCost: number;
    locked?: number; // 冻结数量（做空/对冲）
  };
}

export interface MiningDevice {
  name: string;
  hashrate: number; // H/s
  power: number; // 电费/秒
  unlockCost: number;
  upgradeCost: number; // 单台扩建成本
  count: number;
  unlocked: boolean;
}

export interface MiningState {
  active: boolean;
  totalHashrate: number;
  powerCostPerSecond: number;
  btcPerSecond: number;
  devices: {
    entry: MiningDevice;
    pro: MiningDevice;
    main: MiningDevice;
    asic: MiningDevice;
  };
  shutdownCountdown: number;
}

export interface Trade {
  id: string;
  timestamp: number;
  type: 'buy' | 'sell';
  currencyId: string;
  qty: number;
  price: number;
  total: number;
  source: 'manual' | 'ai';
  aiMode?: 'conservative' | 'balanced' | 'aggressive';
}

export interface Loan {
  id: string;
  principal: number;
  interest: number;
  rate: number; // 日利率 %
  createdAt: number;
  dueAt?: number;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: number;
  progress: number; // 0-100
  reward?: number; // 奖励金额
}

export interface Event {
  id: string;
  timestamp: number;
  type: 'trade' | 'mining' | 'ai' | 'market' | 'achievement' | 'loan';
  title: string;
  description: string;
  icon: string;
  color: string;
  data?: Record<string, any>;
}

export interface GameState {
  // 基础资金
  cash: number;
  bankDeposit: number;
  loanAmount: number;
  loanPrincipal: number;

  // 资产组合
  portfolio: Portfolio;

  // 挖矿系统
  mining: MiningState;

  // 交易历史
  trades: Trade[];

  // 借贷
  loans: Loan[];

  // AI 交易
  aiEnabled: boolean;
  aiMode: 'conservative' | 'balanced' | 'aggressive';
  aiLastTradeTime: number;
  aiTradeInterval: number; // 毫秒

  // 成就系统
  achievements: Achievement[];

  // 事件日志
  events: Event[];

  // 统计数据
  totalProfit: number;
  totalTrades: number;
  winTrades: number;
  maxDrawdown: number;

  // 游戏参数
  difficulty: 'easy' | 'normal' | 'hard';
  startTime: number;
  lastSaveTime: number;

  // 扩展参数
  expandPercent: {
    [key: string]: number;
  };
}

export interface MarketData {
  currencies: Currency[];
  lastUpdate: number;
}

export interface GameAction {
  type: string;
  payload?: any;
}
